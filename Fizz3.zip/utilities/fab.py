def hello(name="world"):
    print("Hello %s!" % name)