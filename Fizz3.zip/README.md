Beacon - a tool to help you be with friends.
============================

We are building Beacon, an online service for getting friends nearby to hangout together. Beacon reduces the hassle of organizing events with friends. But more than that, Beacon acts as an initiator, making accidental hangouts a thing. Using either the web or mobile app, your friends’ Beacon events near you appear on a map, bringing friends who want to hangout together. We provide the structure to bring people together, let your Facebook friends or Twitter followers know where your event is happening, and manage any payments through Venmo integration.

[beaconBeta.com](https://beaconBeta.com/)


## Contributors

- [Joel Simon](http://joelsimon.net)
- [Daniel Belchamber]()


